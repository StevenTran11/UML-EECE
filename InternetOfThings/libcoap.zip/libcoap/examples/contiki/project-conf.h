#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_

#include "coap_config.h"
#define LOG_CONF_LEVEL_COAP 5

#endif /* PROJECT_CONF_H_ */
