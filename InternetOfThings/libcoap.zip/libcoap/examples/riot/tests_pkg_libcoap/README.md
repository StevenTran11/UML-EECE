# libcoap test example

This test is to check that the libcoap client and server logic talk to
each other.

THe client request generates a CoAP request, which is sent to the server
who responds back to the client.
